class cadastroAluno{
	constructor(nome, email, curso, turma, telefone, cpf, ra){
		this.nome = nome;
		this.email = email;
		this.curso = curso;
		this.turma = turma;
		this.telefone = telefone;
		this.cpf = cpf;
		this.ra = ra;
		
	}
}