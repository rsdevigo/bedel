class cadastroServidor{
	constructor(nome, email, endereco, data_de_nascimento, telefone, cpf, siape, senha){
		this.nome = nome;
		this.email = email;
		this.endereco = endereco;
		this.data_de_nascimento = data_de_nascimento;
		this.telefone = telefone;
		this.cpf = cpf;
		this.siape = siape;
		this.senha = senha;
		
	}
}