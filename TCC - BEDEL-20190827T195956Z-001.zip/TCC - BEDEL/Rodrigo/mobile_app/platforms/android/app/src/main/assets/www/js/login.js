class login
{
	constructor(siape, senha)
	{
		this.siape = siape;
		this.senha = senha;
		
	}
}